#ifndef	   __MEM_H__
#define	   __MEM_H__

extern unsigned long getMemSize();
unsigned long memSize();
void detect_mem();

static unsigned long MEM_SIZE=0;

#endif
