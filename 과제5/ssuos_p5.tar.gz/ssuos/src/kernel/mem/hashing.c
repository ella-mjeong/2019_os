#include <device/io.h>
#include <mem/mm.h>
#include <mem/paging.h>
#include <device/console.h>
#include <proc/proc.h>
#include <interrupt.h>
#include <mem/palloc.h>
#include <ssulib.h>
#include <mem/hashing.h>

uint32_t F_IDX(uint32_t addr, uint32_t capacity) {
	return addr % ((capacity / 2) - 1);
}

uint32_t S_IDX(uint32_t addr, uint32_t capacity) {
	return (addr * 7) % ((capacity / 2) - 1) + capacity / 2;
}

void init_hash_table(void)//해시테이블의 값들을 초기화시켜주는 함수
{
	for(int i=0;i<CAPACITY;i++){
		if(i/2==0){
			for(int j=0;j<SLOT_NUM;j++){
				hash_table.bottom_buckets[i/2].token[j]=0; //bottom_level 버킷들의 각 슬롯의 token을 0으로 초기화
				hash_table.bottom_buckets[i/2].slot[j].key=0; //bottom_level 버킷들의 각 슬롯의 key을 0으로 초기화
				hash_table.bottom_buckets[i/2].slot[j].value=0; //bottom_level 버킷들의 각 슬롯의 value를 0으로 초기화
			}
		}
		for(int j=0;j<SLOT_NUM;j++){
			hash_table.top_buckets[i].token[j] = 0; //top_level 버킷들의 각 슬롯의 token을 0으로 초기화
			hash_table.top_buckets[i].slot[j].key = 0; //top_level 버킷들의 각 슬롯의 key을 0으로 초기화
			hash_table.top_buckets[i].slot[j].value = 0; //top_level 버킷들의 각 슬롯의 value를 0으로 초기화
		}
	}
}


void insert_hash(int idx, uint32_t addr){

	uint32_t Fpos, Spos;
	int tmpPos;
	int check=0;
	Fpos = F_IDX(RH_TO_VH(addr), CAPACITY);
	Spos = S_IDX(RH_TO_VH(addr), CAPACITY);
	//첫번째 해시함수와 두번째 해시함수의 인덱스에 해당하는 top-level 버킷들의 슬롯을 각각 번갈아 확인하며 빈 슬롯을 찾는다.	
	for(int i=0;i<SLOT_NUM;i++){
		if(hash_table.top_buckets[Fpos].token[i]==0){ //빈 슬롯이 있다면 아이템을 삽입한다.
			hash_table.top_buckets[Fpos].slot[i].key=idx;
			hash_table.top_buckets[Fpos].slot[i].value = addr;
			hash_table.top_buckets[Fpos].token[i]=1;
			printk("hash value inserted in top level : idx :%3d, key :%2d, value :%7x\n",Fpos,hash_table.top_buckets[Fpos].slot[i].key,hash_table.top_buckets[Fpos].slot[i].value);
			check=1;
			break;
		}

		else if(hash_table.top_buckets[Spos].token[i]==0){ //빈 슬롯이 있다면 아이템을 삽입한다.
			hash_table.top_buckets[Spos].slot[i].key=idx;
			hash_table.top_buckets[Spos].slot[i].value = addr;
			hash_table.top_buckets[Spos].token[i]=1;
			printk("hash value inserted in top level : idx :%3d, key :%2d, value :%7x\n",Spos,hash_table.top_buckets[Spos].slot[i].key,hash_table.top_buckets[Spos].slot[i].value);
			check=1;
			break;
		}
	}


	if(!check){//top-level 버킷들을 다 탐색했는데 빈 슬롯이 없을 때는
		for(int i=0;i<SLOT_NUM;i++){// 첫번째 해시함수와 두번째 해시함수의 인덱스에 해당하는 bottom-level 버킷들의 슬롯을 각각 번갈아 확인하며 빈 슬롯을 찾는다. 
			if(hash_table.bottom_buckets[Fpos/2].token[i]==0){
				hash_table.bottom_buckets[Fpos/2].slot[i].key=idx;
				hash_table.bottom_buckets[Fpos/2].slot[i].value = addr;
				hash_table.bottom_buckets[Fpos/2].token[i]=1;
				printk("hash value inserted in bottom level : idx :%3d, key :%2d, value :%7x\n",Fpos/2,hash_table.bottom_buckets[Fpos/2].slot[i].key,hash_table.bottom_buckets[Fpos/2].slot[i].value);
				check=1;
				break;
			}

			else if(hash_table.bottom_buckets[Spos/2].token[i]==0){
				hash_table.bottom_buckets[Spos/2].slot[i].key=idx;
				hash_table.bottom_buckets[Spos/2].slot[i].value = addr;
				hash_table.bottom_buckets[Spos/2].token[i]=1;
				printk("hash value inserted in bottom level : idx :%3d, key :%2d, value :%7x\n",Spos/2,hash_table.bottom_buckets[Spos/2].slot[i].key,hash_table.bottom_buckets[Spos/2].slot[i].value);
				check=1;
				break;
			}
		}
	}

	//top-level과 bottom-level의 버킷들에 빈 슬롯이 없을 때는 이미 삽입된 아이템 중 하나를 다른 Top-level/bottom-level로 이동 후 아이템 삽입한다.

	if(!check){//toplevel(Fpos) 버킷아이템 중 하나를 다른 toplevel 버킷으로 이동 후 아이템을 삽입한다.
		for(int i=0;i<SLOT_NUM;i++){
			//toplevel(Fpos)안에 있는 아이템들이 F_IDX해시함수를 쓴 결과라고 가정하고 S_IDX해시함수를 이용해서 새로운 인덱스를 구해본다.
			tmpPos = S_IDX(RH_TO_VH(hash_table.top_buckets[Fpos].slot[i].value),CAPACITY);//S_IDX해시함수를 이용해서 새로운 인덱스 구하고
			if(tmpPos == Fpos)//현재 인덱스와 새롭게 구한 인덱스가 같다면 이동이 안되므로 다른 슬롯으로 넘어간다.
				continue;
			for(int j=0;j<SLOT_NUM;j++){ //그 인덱스의 top-level버킷에 빈 슬롯이 있는지 탐색한다.
				if(hash_table.top_buckets[tmpPos].token[j]==0){ //빈 슬롯이 있다면
					hash_table.top_buckets[tmpPos].slot[j].key=hash_table.top_buckets[Fpos].slot[i].key;
					hash_table.top_buckets[tmpPos].slot[j].value = hash_table.top_buckets[Fpos].slot[i].value;
					hash_table.top_buckets[tmpPos].token[j]=1;//아이템이동성공
					printk("hash value inserted in the another top level : idx :%3d, key :%2d, value :%7x\n",tmpPos,hash_table.top_buckets[tmpPos].slot[j].key,hash_table.top_buckets[tmpPos].slot[j].value);

					//비어진 기존슬롯에 아이템을 삽입한다.
					hash_table.top_buckets[Fpos].slot[i].key=idx;
					hash_table.top_buckets[Fpos].slot[i].value = addr;
					hash_table.top_buckets[Fpos].token[i]=1;
					printk("hash value inserted in top level : idx :%3d, key :%2d, value :%7x\n",Fpos,hash_table.top_buckets[Fpos].slot[i].key,hash_table.top_buckets[Fpos].slot[i].value);
					return;
				}
			}

		}


		//새로운 인덱스의 top-level버킷에 빈 슬롯이 존재하지 않았다면
		for(int i=0;i<SLOT_NUM;i++){

			//toplevel(Fpos)안에 있는 아이템들이 S_IDX해시함수를 쓴 결과라고 가정하고 F_IDX해시함수를 이용해서 새로운 인덱스를 구해본다.
			tmpPos = F_IDX(RH_TO_VH(hash_table.top_buckets[Fpos].slot[i].value),CAPACITY);//새로운 인덱스 구하고

			if(tmpPos == Fpos)//현재 인덱스와 새롭게 구한 인덱스가 같다면 이동이 안되므로 다른 슬롯으로 넘어간다.
				continue;
			for(int j=0;j<SLOT_NUM;j++){ //그 인덱스의 top-level버킷에 빈 슬롯이 있는지 탐색한다.
				if(hash_table.top_buckets[tmpPos].token[j]==0){//빈 슬롯이 있다면 아이템을 이동한다.
					hash_table.top_buckets[tmpPos].slot[j].key=hash_table.top_buckets[Fpos].slot[i].key;
					hash_table.top_buckets[tmpPos].slot[j].value = hash_table.top_buckets[Fpos].slot[i].value;
					hash_table.top_buckets[tmpPos].token[j]=1;//아이템이동성공
					printk("hash value inserted in the another top level : idx :%3d, key :%2d, value :%7x\n",tmpPos,hash_table.top_buckets[tmpPos].slot[j].key,hash_table.top_buckets[tmpPos].slot[j].value);

					//비어진 기존슬롯에 아이템을 삽입한다.
					hash_table.top_buckets[Fpos].slot[i].key=idx;
					hash_table.top_buckets[Fpos].slot[i].value = addr;
					hash_table.top_buckets[Fpos].token[i]=1;
					printk("hash value inserted in top level : idx :%3d, key :%2d, value :%7x\n",Fpos,hash_table.top_buckets[Fpos].slot[i].key,hash_table.top_buckets[Fpos].slot[i].value);
					//check_m=1;
					return;
				}

			}
		}

		//toplevel(Spos) 버킷아이템 중 하나를 다른 toplevel 버킷으로 이동 후 아이템을 삽입한다.
		for(int i=0;i<SLOT_NUM;i++){
			//toplevel(Spos)안에 있는 아이템들이 F_IDX해시함수를 쓴 결과라고 가정하고 S_IDX해시함수를 이용해서 새로운 인덱스를 구해본다.
			tmpPos = S_IDX(RH_TO_VH(hash_table.top_buckets[Spos].slot[i].value),CAPACITY);//새로운 인덱스 구하고
			if(tmpPos == Spos)//현재 인덱스와 새롭게 구한 인덱스가 같다면 이동이 안되므로 다른 슬롯으로 넘어간다.
				continue;
			for(int j=0;j<SLOT_NUM;j++){ //그 인덱스의 top-level버킷에 빈 슬롯이 있는지 탐색한다.
				if(hash_table.top_buckets[tmpPos].token[j]==0){//빈 슬롯이 있다면 아이템을 이동한다.
					hash_table.top_buckets[tmpPos].slot[j].key=hash_table.top_buckets[Spos].slot[i].key;
					hash_table.top_buckets[tmpPos].slot[j].value = hash_table.top_buckets[Spos].slot[i].value;
					hash_table.top_buckets[tmpPos].token[j]=1;//아이템이동성공
					printk("hash value inserted in the another top level : idx :%3d, key :%2d, value :%7x\n",tmpPos,hash_table.top_buckets[tmpPos].slot[j].key,hash_table.top_buckets[tmpPos].slot[j].value);

					//비어진 기존슬롯에 아이템을 삽입한다.
					hash_table.top_buckets[Spos].slot[i].key=idx;
					hash_table.top_buckets[Spos].slot[i].value = addr;
					hash_table.top_buckets[Spos].token[i]=1;
					printk("hash value inserted in top level : idx :%3d, key :%2d, value :%7x\n",Spos,hash_table.top_buckets[Spos].slot[i].key,hash_table.top_buckets[Spos].slot[i].value);
					return;
				}
			}

		}

		//새로운 인덱스의 top-level버킷에 빈 슬롯이 존재하지 않았다면
		for(int i=0;i<SLOT_NUM;i++){

			//toplevel(Spos)안에 있는 아이템들이 S_IDX해시함수를 쓴 결과라고 가정하고 F_IDX해시함수를 이용해서 인덱스를 구한다.
			tmpPos = F_IDX(RH_TO_VH(hash_table.top_buckets[Spos].slot[i].value),CAPACITY);//새로운 인덱스 구하고

			if(tmpPos==Spos)//현재 인덱스와 새롭게 구한 인덱스가 같다면 이동이 안되므로 다른 슬롯으로 넘어간다.
				continue;
			for(int j=0;j<SLOT_NUM;j++){ //그 인덱스의 top-level버킷에 빈 슬롯이 있는지 탐색한다.
				if(hash_table.top_buckets[tmpPos].token[j]==0){//빈 슬롯이 있다면 아이템을 이동한다.
					hash_table.top_buckets[tmpPos].slot[j].key=hash_table.top_buckets[Spos].slot[i].key;
					hash_table.top_buckets[tmpPos].slot[j].value = hash_table.top_buckets[Spos].slot[i].value;
					hash_table.top_buckets[tmpPos].token[j]=1;//아이템이동성공
					printk("hash value inserted in the another top level : idx :%3d, key :%2d, value :%7x\n",tmpPos,hash_table.top_buckets[tmpPos].slot[j].key,hash_table.top_buckets[tmpPos].slot[j].value);

					//비어진 기존슬롯에 아이템을 삽입한다.
					hash_table.top_buckets[Spos].slot[i].key=idx;
					hash_table.top_buckets[Spos].slot[i].value = addr;
					hash_table.top_buckets[Spos].token[i]=1;
					printk("hash value inserted in top level : idx :%3d, key :%2d, value :%7x\n",Spos,hash_table.top_buckets[Spos].slot[i].key,hash_table.top_buckets[Spos].slot[i].value);
					return;
				}
			}
		}
		//bottomlevel(Fpos/2) 버킷아이템 중 하나를 다른 toplevel 버킷으로 이동 후 아이템을 삽입한다.
		for(int i=0;i<SLOT_NUM;i++){
			//bottomlevel(Fpos/2)안에 있는 아이템들이 F_IDX해시함수를 쓴 결과라고 가정하고 S_IDX해시함수를 이용해서 새로운 인덱스를 구한다.
			tmpPos = S_IDX(RH_TO_VH(hash_table.bottom_buckets[Fpos/2].slot[i].value),CAPACITY);//새로운 인덱스 구하고
			if((tmpPos/2) == (Fpos/2))//현재 인덱스와 새롭게 구한 인덱스가 같다면 이동이 안되므로 다른 슬롯으로 넘어간다.
				continue;
			for(int j=0;j<SLOT_NUM;j++){ //그 인덱스의 bottom-level버킷에 빈 슬롯이 있는지 탐색한다.
				if(hash_table.bottom_buckets[tmpPos/2].token[j]==0){//빈 슬롯이 있다면 아이템을 이동한다.
					hash_table.bottom_buckets[tmpPos/2].slot[j].key=hash_table.bottom_buckets[Fpos/2].slot[i].key;
					hash_table.bottom_buckets[tmpPos/2].slot[j].value = hash_table.bottom_buckets[Fpos/2].slot[i].value;
					hash_table.bottom_buckets[tmpPos/2].token[j]=1;//아이템이동성공
					printk("hash value inserted in the another bottom level : idx :%3d, key :%2d, value :%7x\n",tmpPos/2,hash_table.bottom_buckets[tmpPos/2].slot[j].key,hash_table.bottom_buckets[tmpPos/2].slot[j].value);

					//비어진 기존슬롯에 아이템을 삽입한다.
					hash_table.bottom_buckets[Fpos/2].slot[i].key=idx;
					hash_table.bottom_buckets[Fpos/2].slot[i].value = addr;
					hash_table.bottom_buckets[Fpos/2].token[i]=1;
					printk("hash value inserted in bottom level : idx :%3d, key :%2d, value :%7x\n", Fpos/2, hash_table.bottom_buckets[Fpos/2].slot[i].key,hash_table.bottom_buckets[Fpos/2].slot[i].value);
					return;
				}
			}
		}

		//새로운 인덱스의 bottom-level버킷에 빈 슬롯이 존재하지 않았다면
		for(int i=0;i<SLOT_NUM;i++){
			//bottomlevel(Fpos/2)안에 있는 아이템들이 S_IDX해시함수를 쓴 결과라고 가정하고 F_IDX해시함수를 이용해서 인덱스를 구한다.
			tmpPos = F_IDX(RH_TO_VH(hash_table.bottom_buckets[Fpos/2].slot[i].value),CAPACITY);//새로운 인덱스 구하고
			if((tmpPos/2)==(Fpos/2))//현재 인덱스와 새롭게 구한 인덱스가 같다면 이동이 안되므로 다른 슬롯으로 넘어간다.
				continue;
			for(int j=0;j<SLOT_NUM;j++){ //그 인덱스의 bottom-level버킷에 빈 슬롯이 있는지 탐색한다.
				if(hash_table.bottom_buckets[tmpPos/2].token[j]==0){ //빈 슬롯이 있다면 아이템을 이동한다.
					hash_table.bottom_buckets[tmpPos/2].slot[j].key=hash_table.bottom_buckets[Fpos/2].slot[i].key;
					hash_table.bottom_buckets[tmpPos/2].slot[j].value = hash_table.bottom_buckets[Fpos/2].slot[i].value;
					hash_table.bottom_buckets[tmpPos/2].token[j]=1;//아이템이동성공
					printk("hash value inserted in the another bottom level : idx :%3d, key :%2d, value :%7x\n",tmpPos/2,hash_table.bottom_buckets[tmpPos/2].slot[j].key,hash_table.bottom_buckets[tmpPos/2].slot[j].value);

					//비어진 기존슬롯에 아이템을 삽입한다.
					hash_table.bottom_buckets[Fpos/2].slot[i].key=idx;
					hash_table.bottom_buckets[Fpos/2].slot[i].value = addr;
					hash_table.bottom_buckets[Fpos/2].token[i]=1;
					printk("hash value inserted in bottom level : idx :%3d, key :%2d, value :%7x\n", Fpos/2, hash_table.bottom_buckets[Fpos/2].slot[i].key,hash_table.bottom_buckets[Fpos/2].slot[i].value);
					return;
				}
			}
		}

		//bottomlevel(Spos/2) 버킷아이템 중 하나를 다른 toplevel 버킷으로 이동 후 아이템을 삽입한다.
		for(int i=0;i<SLOT_NUM;i++){
			//bottomlevel(Spos)안에 있는 아이템들이 F_IDX해시함수를 쓴 결과라고 가정하고 S_IDX해시함수를 이용해서 인덱스를 구한다.
			tmpPos = S_IDX(RH_TO_VH(hash_table.bottom_buckets[Spos/2].slot[i].value),CAPACITY);//새로운 인덱스 구하고
			if((tmpPos/2)==(Spos/2))//현재 인덱스와 새롭게 구한 인덱스가 같다면 이동이 안되므로 다른 슬롯으로 넘어간다.
				continue;
			for(int j=0;j<SLOT_NUM;j++){ //그 인덱스의 bottom-level버킷에 빈 슬롯이 있는지 탐색한다.
				if(hash_table.bottom_buckets[tmpPos/2].token[j]==0){ //빈 슬롯이 있다면 아이템을 이동한다.
					hash_table.bottom_buckets[tmpPos/2].slot[j].key=hash_table.bottom_buckets[Spos/2].slot[i].key;
					hash_table.bottom_buckets[tmpPos/2].slot[j].value = hash_table.bottom_buckets[Spos/2].slot[i].value;
					hash_table.bottom_buckets[tmpPos/2].token[j]=1;//아이템이동성공
					printk("hash value inserted in the another bottom level : idx :%3d, key :%2d, value :%7x\n",tmpPos/2,hash_table.bottom_buckets[tmpPos/2].slot[j].key,hash_table.bottom_buckets[tmpPos/2].slot[j].value);

					//비어진 기존슬롯에 아이템을 삽입한다.
					hash_table.bottom_buckets[Spos/2].slot[i].key=idx;
					hash_table.bottom_buckets[Spos/2].slot[i].value = addr;
					hash_table.bottom_buckets[Spos/2].token[i]=1;
					printk("hash value inserted in bottom level : idx :%3d, key :%2d, value :%7x\n", Spos/2, hash_table.bottom_buckets[Spos/2].slot[i].key,hash_table.bottom_buckets[Spos/2].slot[i].value);
					return;
				}
			}
		}

		//새로운 인덱스의 bottom-level버킷에 빈 슬롯이 존재하지 않았다면
		for(int i=0;i<SLOT_NUM;i++){
			//bottomlevel(Spos/2)안에 있는 아이템들이 S_IDX해시함수를 쓴 결과라고 가정하고 F_IDX해시함수를 이용해서 인덱스를 구한다.
			tmpPos = F_IDX(RH_TO_VH(hash_table.bottom_buckets[Spos/2].slot[i].value),CAPACITY);//새로운 인덱스 구하고
			if((tmpPos/2)==(Spos/2))//현재 인덱스와 새롭게 구한 인덱스가 같다면 이동이 안되므로 다른 슬롯으로 넘어간다.
				continue;
			for(int j=0;j<SLOT_NUM;j++){ //그 인덱스의 bottom-level버킷에 빈 슬롯이 있는지 탐색한다.
				if(hash_table.bottom_buckets[tmpPos/2].token[j]==0){  //빈 슬롯이 있다면 아이템을 이동한다.
					hash_table.bottom_buckets[tmpPos/2].slot[j].key=hash_table.bottom_buckets[Spos/2].slot[i].key;
					hash_table.bottom_buckets[tmpPos/2].slot[j].value = hash_table.bottom_buckets[Spos/2].slot[i].value;
					hash_table.bottom_buckets[tmpPos/2].token[j]=1;//아이템이동성공
					printk("hash value inserted in the another bottom level : idx :%3d, key :%2d, value :%7x\n",tmpPos/2,hash_table.bottom_buckets[tmpPos/2].slot[j].key,hash_table.bottom_buckets[tmpPos/2].slot[j].value);

					//비어진 기존슬롯에 아이템을 삽입한다.
					hash_table.bottom_buckets[Spos/2].slot[i].key=idx;
					hash_table.bottom_buckets[Spos/2].slot[i].value = addr;
					hash_table.bottom_buckets[Spos/2].token[i]=1;
					printk("hash value inserted in bottom level : idx :%3d, key :%2d, value :%7x\n", Spos/2, hash_table.bottom_buckets[Spos/2].slot[i].key,hash_table.bottom_buckets[Spos/2].slot[i].value);
					return;
				}
			}
		}

	}
}

void delete_hash(int idx, uint32_t addr){
	//삭제 연산 시 해시 함수에 대응하는 위치의 top level 버킷 2개와 top level 버킷에 대응하는 각각의 bottom level 버킷, 총 4개의 버킷을 탐색하여 아이템을 찾아 삭제
	uint32_t Fpos, Spos;
	int check=0;
	Fpos = F_IDX(RH_TO_VH(addr), CAPACITY);
	Spos = S_IDX(RH_TO_VH(addr), CAPACITY);

	for(int i=0;i<SLOT_NUM;i++){
		//인덱스가 Fpos인 top-level버킷을 탐색하며 인자로 받은 인덱스와 각각의 슬롯의 key값이 같은지 확인한다.
		if(hash_table.top_buckets[Fpos].slot[i].key==idx){//같다면 해당 아이템을 삭제한다.		
			printk("hash value deleted : idx :%3d, key :%2d, value :%7x\n", Fpos,hash_table.top_buckets[Fpos].slot[i].key,hash_table.top_buckets[Fpos].slot[i].value);
			hash_table.top_buckets[Fpos].token[i]=0;
			hash_table.top_buckets[Fpos].slot[i].key=0;
			hash_table.top_buckets[Fpos].slot[i].value=0;
			check = 1;
			break;
		}
		//인덱스가 Spos인 top-level버킷을 탐색하며 인자로 받은 인덱스와 각각의 슬롯의 key값이 같은지 확인한다.
		else if(hash_table.top_buckets[Spos].slot[i].key==idx){//같다면 해당 아이템을 삭제한다.	
			printk("hash value deleted : idx :%3d, key :%2d, value :%7x\n", Spos,hash_table.top_buckets[Spos].slot[i].key,hash_table.top_buckets[Spos].slot[i].value);
			hash_table.top_buckets[Spos].token[i]=0;
			hash_table.top_buckets[Spos].slot[i].key=0;
			hash_table.top_buckets[Spos].slot[i].value=0;
			check = 1;
			break;
		}
	}

	if(!check){//top-level 버킷에는 찾고자하는 아이템이 존재하지 않을 때
		for(int i=0;i<SLOT_NUM;i++){
			//인덱스가 Fpos/2인 bottom-level버킷을 탐색하며 인자로 받은 인덱스와 각각의 슬롯의 key값이 같은지 확인한다.
			if(hash_table.bottom_buckets[Fpos/2].slot[i].key==idx){//같다면 해당 아이템을 삭제한다.	
				printk("hash value deleted : idx :%3d, key :%2d, value :%7x\n",Fpos/2,hash_table.bottom_buckets[Fpos/2].slot[i].key, hash_table.bottom_buckets[Fpos/2].slot[i].value);
				hash_table.bottom_buckets[Fpos/2].token[i]=0;
				hash_table.bottom_buckets[Fpos/2].slot[i].key=0;
				hash_table.bottom_buckets[Fpos/2].slot[i].value=0;
				check = 1;
				break;
			}
			//인덱스가 Spos/2인 bottom-level버킷을 탐색하며 인자로 받은 인덱스와 각각의 슬롯의 key값이 같은지 확인한다.
			else if(hash_table.bottom_buckets[Spos/2].slot[i].key==idx){//같다면 해당 아이템을 삭제한다.
				printk("hash value deleted : idx :%3d, key :%2d, value :%7x\n",Spos/2,hash_table.bottom_buckets[Spos/2].slot[i].key, hash_table.bottom_buckets[Spos/2].slot[i].value);
				hash_table.bottom_buckets[Spos/2].token[i]=0;
				hash_table.bottom_buckets[Spos/2].slot[i].key=0;
				hash_table.bottom_buckets[Spos/2].slot[i].value=0;
				check = 1;
				break;
			}
		}
	}
}


