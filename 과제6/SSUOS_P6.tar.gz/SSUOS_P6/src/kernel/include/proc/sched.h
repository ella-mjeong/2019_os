#ifndef		__SCHED_H__
#define		__SCHED_H__

#include <list.h>
#include <proc/proc.h>

void schedule(void);

#endif
