#include <mem/palloc.h>
#include <bitmap.h>
#include <type.h>
#include <round.h>
#include <mem/mm.h>
#include <synch.h>
#include <device/console.h>
#include <mem/paging.h>
#include<mem/swap.h>

/* Page allocator.  Hands out memory in page-size (or
   page-multiple) chunks.  
 */
/* pool for memory */
struct memory_pool
{
	struct lock lock;                   
	struct bitmap *bitmap; 
	uint32_t *addr;                    
};
/* kernel heap page struct */
struct khpage{
	uint16_t page_type;
	uint16_t nalloc;
	uint32_t used_bit[4];
	struct khpage *next;
};

/* free list */
struct freelist{
	struct khpage *list;
	int nfree;
};

static struct khpage *khpage_list;
static struct freelist freelist;
static uint32_t page_alloc_index;


struct memory_pool user_pool;
struct memory_pool kernel_pool;
bool pool_p ( struct memory_pool *pool, void *page);


/* Initializes the page allocator. */
//
	void
init_palloc (void) 
{

	size_t bm_pages = DIV_ROUND_UP (bitmap_struct_size (1), PGSIZE);

	lock_init (&user_pool.lock);
	lock_init (&kernel_pool.lock);
	user_pool.bitmap = create_bitmap((RKERNEL_HEAP_START-USER_POOL_START)/PAGE_SIZE,USER_POOL_START,bm_pages * PGSIZE); //user_pool에 bitmap생성
	kernel_pool.bitmap = create_bitmap((USER_POOL_START-KERNEL_ADDR)/PAGE_SIZE, KERNEL_ADDR,bm_pages * PGSIZE); //kernel_pool에 bitmap생성 
	user_pool.addr = USER_POOL_START + bm_pages * PGSIZE; //user_pool의 addr 설정
	kernel_pool.addr = KERNEL_ADDR + bm_pages * PGSIZE; //kernel_pool의 addr 설정 

}



/* Obtains and returns a group of PAGE_CNT contiguous free pages.
 */
void* palloc_get_multiple_page(enum palloc_flags flags, size_t page_cnt){
	struct memory_pool* tmp_pool;
	void *pages;
	size_t page_idx;
	size_t tm;
	if (page_cnt == 0)
		return NULL;

	//flags에 따라 kernel mode인지 user_mode인지 판단
	if(flags==0){//kernel mode라면
		tmp_pool = &kernel_pool;	
	}
	else if(flags == 1){//user mode라면 
		tmp_pool = &user_pool;
	}

	lock_acquire (&tmp_pool->lock);
	page_idx = find_set_bitmap(tmp_pool->bitmap, 0, page_cnt, FALSE);//bitmap에서 비어있는 인덱스 찾아 할당
	lock_release (&tmp_pool->lock);

	if (page_idx != BITMAP_ERROR){
		pages = (size_t *)tmp_pool->addr + (page_idx * PAGE_SIZE/sizeof(page_idx));
	}
	else
		pages = NULL;

	if (pages != NULL)
	{
		memset (pages, 0, PGSIZE * page_cnt);
	}

	return pages;


}

/* Obtains a single free page and returns its address.
 */
void* palloc_get_one_page (enum palloc_flags flags) 
{
	return palloc_get_multiple_page (flags, 1); //1페이지 할당할때 
}

/* Frees the PAGE_CNT pages starting at PAGES. */
uint32_t *palloc_free_multiple_page(void *pages, size_t page_cnt){

	struct memory_pool* tmp_pool;
	size_t page_idx;


	if (pages == NULL || page_cnt == 0)
		return NULL;

	if(pool_p(&kernel_pool, pages)){ //kernel_pool이라면

		tmp_pool = &kernel_pool;
	}

	else if(pool_p(&user_pool, pages)){ //user_pool이라면

		tmp_pool = &user_pool;
	}

	page_idx = pg_no(pages) - pg_no(tmp_pool->addr); //해제해야할 인덱스 찾기

	if(bitmap_all (tmp_pool->bitmap, page_idx, page_cnt))
		set_multi_bitmap (tmp_pool->bitmap, page_idx, page_cnt, FALSE); //비트맵에서 해당하는 인덱스 찾아 페이지 해제해주기

	return tmp_pool->addr;

}

/* Frees the page at PAGE. */
uint32_t *palloc_free_one_page (void *pages){
	palloc_free_multiple_page (pages, 1); //한페이지 해제할때
}



bool pool_p( struct memory_pool *pool, void *page) //해제해야할 페이지가 user_pool에 있는지 kernel_pool에 있는지 페이지 주소로 판단하는 함수
{
	return (pg_no (page) >= pg_no (pool->addr) && pg_no (page) < (pg_no (pool->addr) + bitmap_size (pool->bitmap)));

}
void palloc_pf_test(void)
{
	uint32_t *one_page1 = palloc_get_one_page(user_area);
	uint32_t *one_page2 = palloc_get_one_page(user_area);
	uint32_t *two_page1 = palloc_get_multiple_page(user_area,2);
	uint32_t *three_page;
	printk("one_page1 = %x\n", one_page1); 
	printk("one_page2 = %x\n", one_page2); 
	printk("two_page1 = %x\n", two_page1);	

	printk("=----------------------------------=\n");
	palloc_free_one_page(one_page1);	
	palloc_free_one_page(one_page2);
	palloc_free_multiple_page(two_page1,2); 

	one_page1 = palloc_get_one_page(user_area); 
	one_page2 = palloc_get_one_page(user_area); 
	two_page1 = palloc_get_multiple_page(user_area,2); 

	printk("one_page1 = %x\n", one_page1);
	printk("one_page2 = %x\n", one_page2);
	printk("two_page1 = %x\n", two_page1);

	printk("=----------------------------------=\n");
	palloc_free_multiple_page(one_page2, 3); 
	one_page2 = palloc_get_one_page(user_area); 
	three_page = palloc_get_multiple_page(user_area,3); 

	printk("one_page1 = %x\n", one_page1); 
	printk("one_page2 = %x\n", one_page2); 
	printk("three_page = %x\n", three_page); 

	palloc_free_one_page(one_page1);
	palloc_free_one_page(three_page);
	three_page = (uint32_t*)((uint32_t)three_page + 0x1000);
	palloc_free_one_page(three_page);
	three_page = (uint32_t*)((uint32_t)three_page + 0x1000);
	palloc_free_one_page(three_page);
	palloc_free_one_page(one_page2);
}
