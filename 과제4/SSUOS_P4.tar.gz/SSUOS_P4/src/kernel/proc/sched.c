#include <list.h>
#include <proc/sched.h>
#include <mem/malloc.h>
#include <proc/proc.h>
#include <proc/switch.h>
#include <interrupt.h>

extern struct list plist;
extern struct list rlist;
extern struct list runq[RQ_NQS];

extern struct process procs[PROC_NUM_MAX];
extern struct process *idle_process;
struct process *latest;

bool more_prio(const struct list_elem *a, const struct list_elem *b,void *aux);
int scheduling; 					// interrupt.c

struct process* get_next_proc(void) {

	bool found = false;
	struct process *next = NULL;
	struct list_elem *elem;

	/* 
	   You shoud modify this function...
	   Browse the 'runq' array 
	 */

	for(int i=0;i<RQ_NQS;i++){ 
		if(list_empty(&runq[i])) 
			continue;

		for(elem = list_begin(&runq[i]); elem != list_end(&runq[i]); elem = list_next(elem)) 
		{
			struct process *p = list_entry(elem, struct process, elem_stat);

			if(p->state == PROC_RUN) 
				return p;
		}
	}

	return next;
}

void schedule(void)
{
	struct process *cur;
	struct process *next;
	struct process *tmp;
	struct list_elem *elem;
	
	int printed = 0;
	/* You shoud modify this function.... */
	intr_set_level(0); 
	scheduling = 1;

	cur = cur_process;
	if(cur_process->pid != 0){ 
		cur_process=idle_process;
		latest=cur;

		switch_process(cur,idle_process);
		intr_set_level(1); 
		return;
	}

	proc_wake();

	for (elem = list_begin(&plist); elem != list_end(&plist); elem = list_next(elem)) {
		tmp = list_entry (elem, struct process, elem_all);

		if ((tmp -> state == PROC_ZOMBIE) || (tmp -> state == PROC_BLOCK) || (tmp -> state == PROC_STOP) || (tmp -> state == PROC_UNUSED) || (tmp -> pid == 0)) 	
			continue;
		if (!printed) {
			printk("#=%2d p= %4d c=%3d u=%3d ", tmp -> pid, tmp->priority, tmp -> time_slice, tmp->time_used);
			printed=1;
		}
		else{
			printk(", #=%2d p= %4d c=%3d u=%3d ", tmp -> pid, tmp->priority, tmp -> time_slice, tmp->time_used);
		}

	}
	if (printed)
		printk("\n");

	if((next = get_next_proc())!= NULL){ 
		if(next->pid != 0)
			printk("Selected # = %d\n", next->pid);
		cur_process = next;
		cur_process->time_slice = 0;
		scheduling=0;
		switch_process(cur, next);
		intr_set_level(1); 
		return;
	}
	return;

}
